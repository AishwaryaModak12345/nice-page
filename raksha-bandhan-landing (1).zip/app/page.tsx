"use client"

import { Sparkles, Gift, ShieldCheck, ArrowRight, Candy } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import MandalaBg from "@/components/mandala-bg"
import Hero from "@/components/hero"
import StoryCarousel from "@/components/story-carousel"
import Gallery from "@/components/gallery"
import Footer from "@/components/footer"
import { motion } from "framer-motion"

export default function Page() {
  return (
    <main className="relative min-h-screen overflow-x-hidden">
      <MandalaBg />
      {/* Announcement banner with orange/blue accents */}
      <div className="w-full bg-gradient-to-r from-orange-500 via-rose-500 to-sky-500 text-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-2 py-2 text-sm">
            <Sparkles className="h-4 w-4" aria-hidden="true" />
            <span className="font-medium">Celebrate the bond: Special Rakhi collections now live!</span>
          </div>
        </div>
      </div>

      {/* Header / Nav - maroon */}
      <header className="sticky top-0 z-40 w-full border-b border-[#D4AF37]/20 bg-[#8B0000]/95 backdrop-blur supports-[backdrop-filter]:bg-[#8B0000]/75">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <Link href="#" className="flex items-center gap-2">
            <span className="sr-only">Home</span>
            <ShieldCheck className="h-5 w-5 text-[#F5D76E]" aria-hidden="true" />
            <span className="bg-clip-text text-transparent bg-gradient-to-b from-[#F5D76E] to-[#D4AF37] font-semibold">
              Raksha Bandhan
            </span>
          </Link>
          <nav className="hidden items-center gap-6 md:flex">
            <a href="#story" className="text-sm text-white/90 hover:text-white">
              Story
            </a>
            <a href="#gallery" className="text-sm text-white/90 hover:text-white">
              Rakhi Designs
            </a>
            <a href="#traditions" className="text-sm text-white/90 hover:text-white">
              Traditions
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <Button
              asChild
              className="bg-[#8B0000] hover:bg-[#7a0000] text-white border border-[#D4AF37]/40 shadow-[0_0_0_1px_rgba(212,175,55,0.25)]"
            >
              <Link href="#gallery">
                Shop Rakhis
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <Hero />

      {/* Story Section */}
      <section id="story" className="relative py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center space-y-3">
            <Badge className="mx-auto bg-gradient-to-r from-orange-500 to-sky-500 text-white shadow">The Story</Badge>
            <h2 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-[#F5D76E] to-[#D4AF37]">
              The Essence of Raksha Bandhan
            </h2>
            <p className="text-muted-foreground">
              A timeless tradition where sisters tie a sacred thread and brothers pledge love, protection, and support.
            </p>
          </div>
          <div className="mt-8 md:mt-12">
            <StoryCarousel />
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="container mx-auto px-4">
        <hr className="my-6 border-t border-[#D4AF37]/40" />
      </div>

      {/* Gallery Section */}
      <section id="gallery" className="relative py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center space-y-3">
            <Badge variant="outline" className="mx-auto border-[#D4AF37] text-[#D4AF37]">
              Gallery
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-[#F5D76E] to-[#D4AF37]">
              Rakhi Designs & Festive Moments
            </h2>
            <p className="text-muted-foreground">
              Explore handcrafted rakhis, delicious sweets, and heartwarming moments of the ceremony.
            </p>
          </div>
          <div className="mt-8 md:mt-12">
            <Gallery />
          </div>
        </div>
      </section>

      {/* Traditions */}
      <section id="traditions" className="relative py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-2">
            <div className="relative overflow-hidden rounded-2xl border border-[#D4AF37]/30 bg-white/70 backdrop-blur">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#F5D76E]/10 via-transparent to-transparent pointer-events-none" />
              <div className="p-6 md:p-8">
                <div className="flex items-center gap-3">
                  <Candy className="h-6 w-6 text-[#D4AF37]" aria-hidden="true" />
                  <h3 className="text-2xl font-semibold text-[#D4AF37]">Sweets & Blessings</h3>
                </div>
                <p className="mt-2 text-muted-foreground">
                  No celebration is complete without sweets. From laddoos to soan papdi, sharing mithai symbolizes joy
                  and togetherness.
                </p>
                <div className="mt-6 relative aspect-[16/10] w-full overflow-hidden rounded-xl">
                  <Image
                    src="/images/sweets-ladoo.png"
                    alt="Traditional Indian laddoos in a festive setting"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                    priority
                  />
                </div>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-2xl border border-[#D4AF37]/30 bg-white/70 backdrop-blur">
              <div className="absolute inset-0 bg-[conic-gradient(from_180deg_at_50%_50%,_rgba(245,215,110,0.08),_transparent)] pointer-events-none" />
              <div className="p-6 md:p-8">
                <div className="flex items-center gap-3">
                  <Gift className="h-6 w-6 text-[#D4AF37]" aria-hidden="true" />
                  <h3 className="text-2xl font-semibold text-[#D4AF37]">The Sacred Thread</h3>
                </div>
                <p className="mt-2 text-muted-foreground">
                  Sisters tie rakhi, perform aarti, and apply tilak—an age-old ritual celebrating love, protection, and
                  gratitude.
                </p>
                <motion.div
                  className="mt-6 relative aspect-[16/10] w-full overflow-hidden rounded-xl"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  <Image
                    src="/images/siblings-tying-1.png"
                    alt="Sister tying rakhi on her brother's wrist amid marigolds and diya"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                    priority
                  />
                  <div className="pointer-events-none absolute inset-0 rounded-xl ring-1 ring-[#D4AF37]/40" />
                  <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(245,215,110,0.15),transparent_35%),radial-gradient(circle_at_80%_80%,rgba(255,153,51,0.12),transparent_40%)] opacity-0 transition-opacity duration-500 hover:opacity-100" />
                  <span className="absolute left-3 top-3 z-10 rounded-full bg-gradient-to-r from-[#F5D76E] to-[#D4AF37] px-2 py-0.5 text-xs font-semibold text-[#8B0000] shadow">
                    Upgraded
                  </span>
                </motion.div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-12 overflow-hidden rounded-2xl border border-[#D4AF37]/30 bg-[#8B0000]">
            <div className="px-6 py-10 md:px-10 md:py-12 text-center text-white relative">
              <div className="absolute inset-0 opacity-15 pointer-events-none [mask-image:radial-gradient(50%_50%_at_50%_50%,_black,_transparent)]">
                <Image src="/images/mandala-gold.png" alt="" fill className="object-cover" />
              </div>
              <h3 className="text-2xl md:text-3xl font-semibold bg-clip-text text-transparent bg-gradient-to-b from-[#F5D76E] to-[#D4AF37]">
                Send Love, Share Sweets, Tie the Bond
              </h3>
              <p className="mt-2 text-white/90">
                Choose from premium rakhis and curated gift hampers with quick delivery.
              </p>
              <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
                <Button asChild className="bg-[#DC143C] hover:bg-[#c01335] text-white border border-[#D4AF37]/40">
                  <Link href="#gallery">Explore Designs</Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="border-[#D4AF37] text-[#D4AF37] bg-transparent hover:bg-white/10"
                >
                  <Link href="#story">Learn the Tradition</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
