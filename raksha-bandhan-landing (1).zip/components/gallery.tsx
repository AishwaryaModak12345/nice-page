"use client"

import { useMemo, useState } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import { cn } from "@/lib/utils"

type Item = {
  id: string
  title: string
  category: "Rakhis" | "Sweets" | "Moments"
  src: string
  alt: string
}

const itemsData: Item[] = [
  {
    id: "r1",
    title: "Kundan Rakhi",
    category: "Rakhis",
    src: "/images/rakhi-1.png",
    alt: "Kundan rakhi with red thread and gold accents",
  },
  {
    id: "r2",
    title: "Beaded Rakhi",
    category: "Rakhis",
    src: "/images/rakhi-2.png",
    alt: "Beaded rakhi in gold and red on festive fabric",
  },
  {
    id: "r3",
    title: "Peacock Motif",
    category: "Rakhis",
    src: "/images/rakhi-3.png",
    alt: "Peacock motif rakhi with blue and orange accents",
  },
  {
    id: "s1",
    title: "Laddoos Platter",
    category: "Sweets",
    src: "/images/sweets-ladoo.png",
    alt: "Golden laddoos arranged on a brass plate",
  },
  {
    id: "s2",
    title: "Soan Papdi",
    category: "Sweets",
    src: "/images/sweets-soan-papdi.png",
    alt: "Stack of soan papdi squares with almonds",
  },
  {
    id: "m1",
    title: "Tying Rakhi",
    category: "Moments",
    src: "/images/siblings-tying-1.png",
    alt: "Sister tying rakhi on brother's wrist during ceremony",
  },
  {
    id: "m2",
    title: "Smiles & Gifts",
    category: "Moments",
    src: "/images/siblings-smiling-2.png",
    alt: "Siblings smiling and exchanging gifts",
  },
  {
    id: "m3",
    title: "Diya & Flowers",
    category: "Moments",
    src: "/images/diya-flowers.png",
    alt: "Decorative diya with marigold flowers",
  },
]

const categories = ["All", "Rakhis", "Sweets", "Moments"] as const
type Category = (typeof categories)[number]

export default function Gallery() {
  const [active, setActive] = useState<Category>("All")
  const items = useMemo(() => (active === "All" ? itemsData : itemsData.filter((i) => i.category === active)), [active])

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-wrap justify-center gap-2">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setActive(c)}
            className={cn(
              "rounded-full border px-3 py-1 text-sm transition-colors",
              c === active
                ? "border-[#D4AF37] bg-[#D4AF37]/10 text-[#8B0000]"
                : "border-[#D4AF37]/40 text-[#8B0000]/80 hover:bg-[#D4AF37]/10",
            )}
            aria-pressed={c === active}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item, idx) => (
          <motion.article
            key={item.id}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            whileHover={{ y: -4, scale: 1.01 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.4, delay: idx * 0.04 }}
            className="group relative overflow-hidden rounded-xl border border-[#D4AF37]/30 bg-white/70 shadow-sm backdrop-blur"
          >
            {item.id === "r2" && (
              <div className="absolute left-3 top-3 z-10 rounded-full bg-gradient-to-r from-[#F5D76E] to-[#D4AF37] px-2 py-0.5 text-xs font-semibold text-[#8B0000] shadow">
                Featured
              </div>
            )}
            <div className="relative aspect-[4/3] w-full overflow-hidden">
              <Image
                src={item.src || "/placeholder.svg"}
                alt={item.alt}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
                sizes="(max-width: 1024px) 100vw, 33vw"
              />
            </div>
            <div className="flex items-center justify-between p-3">
              <div>
                <h4 className="font-medium text-[#8B0000]">{item.title}</h4>
                <p className="text-xs text-muted-foreground">{item.category}</p>
              </div>
              <div className="h-2 w-2 rounded-full bg-gradient-to-tr from-orange-500 to-sky-500 shadow-[0_0_0_3px_rgba(212,175,55,0.25)]" />
            </div>
            {/* Gold glow on hover */}
            <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              <div className="absolute inset-0 rounded-xl ring-2 ring-[#D4AF37]/40" />
              <div className="absolute -inset-6 -z-10 bg-[#D4AF37]/20 blur-2xl" />
            </div>
            {item.id === "r2" && (
              <div className="pointer-events-none absolute inset-0">
                <div className="absolute -inset-8 bg-[radial-gradient(circle_at_25%_20%,rgba(245,215,110,0.18),transparent_40%),radial-gradient(circle_at_80%_75%,rgba(255,153,51,0.18),transparent_45%)] opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              </div>
            )}
          </motion.article>
        ))}
      </div>
    </div>
  )
}
