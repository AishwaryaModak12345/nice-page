"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Sparkles, ArrowRight } from "lucide-react"

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="container mx-auto grid items-center gap-10 px-4 py-12 md:grid-cols-2 md:py-20">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="relative z-10"
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-white/60 px-3 py-1 text-sm text-[#8B0000] backdrop-blur">
            <Sparkles className="h-4 w-4 text-[#D4AF37]" aria-hidden="true" />
            Celebrate together on August 2025
          </div>
          <h1 className="mt-4 text-4xl font-extrabold tracking-tight md:text-6xl bg-clip-text text-transparent bg-gradient-to-b from-[#F5D76E] to-[#D4AF37]">
            Happy Raksha Bandhan
          </h1>
          <p className="mt-3 max-w-xl text-base md:text-lg text-muted-foreground">
            Honoring the timeless bond between brothers and sisters with sacred rituals, sweets, and heartfelt promises.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button asChild className="bg-[#8B0000] hover:bg-[#7a0000] text-white border border-[#D4AF37]/40">
              <Link href="#gallery">
                Browse Rakhi Designs
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10 bg-transparent"
            >
              <Link href="#story">See the Story</Link>
            </Button>
          </div>
        </motion.div>

        {/* Image collage with motion */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.1 }}
          className="relative"
        >
          <div className="relative mx-auto aspect-[4/3] w-full max-w-xl">
            {/* Backdrop glow */}
            <div className="absolute -inset-6 rounded-3xl bg-gradient-to-tr from-orange-500/20 via-transparent to-sky-500/20 blur-2xl" />
            {/* Layers */}
            <motion.div
              className="absolute left-0 top-6 h-[48%] w-[58%] overflow-hidden rounded-2xl border border-[#D4AF37]/30 shadow"
              whileHover={{ scale: 1.02 }}
            >
              <Image
                src="/images/rakhi-1.png"
                alt="Handcrafted rakhi with gold beads"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 90vw, 30vw"
                priority
              />
            </motion.div>
            <motion.div
              className="absolute right-0 top-0 h-[42%] w-[48%] overflow-hidden rounded-2xl border border-[#D4AF37]/30 shadow"
              whileHover={{ scale: 1.02 }}
            >
              <Image
                src="/images/siblings-smiling-2.png"
                alt="Brother and sister smiling during Raksha Bandhan"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 90vw, 30vw"
              />
            </motion.div>
            <motion.div
              className="absolute bottom-0 right-6 h-[44%] w-[56%] overflow-hidden rounded-2xl border border-[#D4AF37]/30 shadow"
              whileHover={{ scale: 1.02 }}
            >
              <Image
                src="/images/sweets-soan-papdi.png"
                alt="Soan papdi and festive sweets"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 90vw, 30vw"
              />
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
