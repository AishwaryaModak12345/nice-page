"use client"

import Image from "next/image"

export default function MandalaBg() {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10">
      {/* Soft gradient wash */}
      <div className="absolute inset-0 bg-[radial-gradient(80%_60%_at_50%_0%,_rgba(245,215,110,0.15),_transparent_60%)]" />
      {/* Gold mandala texture */}
      <div className="absolute inset-0 opacity-15">
        <Image src="/images/mandala-gold.png" alt="" fill priority className="object-cover" />
      </div>
      {/* Subtle noise overlay */}
      <div
        className="absolute inset-0 mix-blend-overlay opacity-10"
        style={{ backgroundImage: "url('/abstract-noise.png')" }}
      />
    </div>
  )
}
