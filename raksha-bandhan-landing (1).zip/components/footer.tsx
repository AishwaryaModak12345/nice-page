import Link from "next/link"

export default function Footer() {
  return (
    <footer className="border-t border-[#D4AF37]/30 bg-white/70">
      <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
        <div className="flex flex-col items-center gap-2">
          <p>
            {"© "}
            <span className="font-medium text-[#8B0000]">Raksha Bandhan</span>
            {" · "}
            <span className="text-[#D4AF37]">Spreading love and protection</span>
          </p>
          <nav className="flex gap-4">
            <Link href="#story" className="hover:text-foreground">
              Story
            </Link>
            <Link href="#gallery" className="hover:text-foreground">
              Rakhi Designs
            </Link>
            <Link href="#traditions" className="hover:text-foreground">
              Traditions
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  )
}
