"use client"

import { useEffect, useMemo, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, ArrowLeft, Gift, Heart } from "lucide-react"

type Slide = {
  title: string
  description: string
  image: string
}

const slidesData: Slide[] = [
  {
    title: "Preparations",
    description:
      "Homes are adorned with rangoli and flowers. Sisters prepare thalis with diyas, tilak, and beautiful rakhis.",
    image: "/images/diya-flowers.png",
  },
  {
    title: "The Ritual",
    description:
      "Sisters tie the sacred rakhi, perform aarti, and apply tilak—blessing their brothers with love and protection.",
    image: "/images/siblings-tying-1.png",
  },
  {
    title: "Sweets & Smiles",
    description: "Sweet treats like laddoos and soan papdi are shared, sealing the moment with joy and gratitude.",
    image: "/images/sweets-ladoo.png",
  },
  {
    title: "Gifts & Promises",
    description: "Brothers give gifts and pledge support, while sisters wish for their well-being and success.",
    image: "/images/rakhi-2.png",
  },
  {
    title: "Togetherness",
    description: "Families gather, share meals, and relive memories—strengthening the bond year after year.",
    image: "/images/siblings-smiling-2.png",
  },
]

export default function StoryCarousel() {
  const slides = useMemo(() => slidesData, [])
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)

  useEffect(() => {
    if (paused) return
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % slides.length)
    }, 4500)
    return () => clearInterval(id)
  }, [slides.length, paused])

  return (
    <div
      className="relative mx-auto max-w-5xl overflow-hidden rounded-2xl border border-[#D4AF37]/30 bg-white/70 backdrop-blur"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="grid gap-0 md:grid-cols-2">
        <div className="relative aspect-[16/11] w-full md:aspect-auto md:min-h-[360px]">
          <AnimatePresence initial={false} mode="popLayout">
            <motion.div
              key={slides[index].image}
              initial={{ opacity: 0, scale: 1.02 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0.2 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="absolute inset-0"
            >
              <Image
                src={slides[index].image || "/placeholder.svg"}
                alt={slides[index].title}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
                priority={index === 0}
              />
            </motion.div>
          </AnimatePresence>
          <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_top,rgba(0,0,0,0.25),transparent_40%)]" />
        </div>

        <div className="relative p-6 md:p-8">
          <div className="absolute inset-0 opacity-20 pointer-events-none [mask-image:radial-gradient(60%_60%_at_50%_50%,_black,_transparent)]">
            <Image src="/images/mandala-gold.png" alt="" fill className="object-cover" />
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={slides[index].title}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.45 }}
              className="relative"
            >
              <div className="inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-white/60 px-3 py-1 text-xs text-[#8B0000] backdrop-blur">
                {index % 2 === 0 ? (
                  <Gift className="h-3.5 w-3.5 text-[#D4AF37]" />
                ) : (
                  <Heart className="h-3.5 w-3.5 text-[#D4AF37]" />
                )}
                {index + 1} / {slides.length}
              </div>
              <h3 className="mt-3 text-2xl font-semibold text-[#D4AF37]">{slides[index].title}</h3>
              <p className="mt-2 text-muted-foreground">{slides[index].description}</p>
            </motion.div>
          </AnimatePresence>

          <div className="mt-6 flex items-center justify-between">
            <div className="flex gap-1.5">
              {slides.map((_, i) => (
                <button
                  key={i}
                  aria-label={`Go to slide ${i + 1}`}
                  onClick={() => setIndex(i)}
                  className={`h-2 rounded-full transition-all ${
                    i === index ? "w-6 bg-[#D4AF37]" : "w-2 bg-[#D4AF37]/40 hover:bg-[#D4AF37]/70"
                  }`}
                />
              ))}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="border-[#D4AF37] text-[#D4AF37] bg-transparent"
                onClick={() => setIndex((i) => (i - 1 + slides.length) % slides.length)}
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Previous</span>
              </Button>
              <Button
                variant="outline"
                className="border-[#D4AF37] text-[#D4AF37] bg-transparent"
                onClick={() => setIndex((i) => (i + 1) % slides.length)}
              >
                <ArrowRight className="h-4 w-4" />
                <span className="sr-only">Next</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
